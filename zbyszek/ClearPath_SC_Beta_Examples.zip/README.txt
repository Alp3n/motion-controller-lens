ClearPath-SC Beta C++ Examples (Windows)
========================================

DISCLAIMER
----------
These example projects have been generally tested and confirmed to build
and run on Windows without modifications. However, they have NOT yet gone
through Teknic’s full, exhaustive test plan. They are provided as beta
content to supplement the standard SDK examples included with ClearView.

SETUP INSTRUCTIONS
------------------
1. Install ClearView (if you haven’t already):
   https://teknic.com/files/downloads/ClearView_Install.zip

2. Once installed, copy the entire "beta-cpp-examples-windows" folder into:
   C:\Program Files (x86)\Teknic\ClearView\sdk

   Do NOT place them inside the "sdk\examples" folder.

HELP / CONTACT
--------------
If you have any difficulties or questions, please reach out to us.
A Teknic Applications Engineer will be happy to assist you.

Teknic Inc.
Phone: 585-784-7454
Contact Form: https://teknic.com/contact